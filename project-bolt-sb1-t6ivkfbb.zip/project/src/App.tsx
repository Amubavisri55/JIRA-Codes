import React, { useState } from 'react';
import { Droplet, Users, Heart } from 'lucide-react';

type FormType = 'donor' | 'recipient' | null;

function App() {
  const [formType, setFormType] = useState<FormType>(null);

  const DonorForm = () => (
    <form className="space-y-4 w-full max-w-2xl">
      <h2 className="text-2xl font-bold text-red-700 mb-6">Blood Donation Form</h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Full Name</label>
          <input type="text" className="w-full p-2 border rounded" required />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Age</label>
          <input type="number" className="w-full p-2 border rounded" required />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Blood Type</label>
          <select className="w-full p-2 border rounded" required>
            <option value="">Select Blood Type</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Mobile Number</label>
          <input type="tel" className="w-full p-2 border rounded" required />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-medium">Health Status</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Do you consume alcohol?</label>
            <div className="space-x-4">
              <input type="radio" name="alcohol" value="yes" id="alcohol-yes" />
              <label htmlFor="alcohol-yes">Yes</label>
              <input type="radio" name="alcohol" value="no" id="alcohol-no" />
              <label htmlFor="alcohol-no">No</label>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Do you smoke?</label>
            <div className="space-x-4">
              <input type="radio" name="smoking" value="yes" id="smoking-yes" />
              <label htmlFor="smoking-yes">Yes</label>
              <input type="radio" name="smoking" value="no" id="smoking-no" />
              <label htmlFor="smoking-no">No</label>
            </div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Hospital Location</label>
        <select className="w-full p-2 border rounded" required>
          <option value="">Select Government Hospital</option>
          <option value="hospital1">Government General Hospital</option>
          <option value="hospital2">District Government Hospital</option>
          <option value="hospital3">Primary Health Center</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Any Medical Conditions</label>
        <textarea className="w-full p-2 border rounded" rows={3}></textarea>
      </div>

      <button type="submit" className="w-full bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 transition">
        Submit Donation Request
      </button>
    </form>
  );

  const RecipientForm = () => (
    <form className="space-y-4 w-full max-w-2xl">
      <h2 className="text-2xl font-bold text-red-700 mb-6">Blood Request Form</h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Patient Name</label>
          <input type="text" className="w-full p-2 border rounded" required />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Age</label>
          <input type="number" className="w-full p-2 border rounded" required />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Required Blood Type</label>
          <select className="w-full p-2 border rounded" required>
            <option value="">Select Blood Type</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Units Required</label>
          <input type="number" className="w-full p-2 border rounded" required />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Hospital Name</label>
          <select className="w-full p-2 border rounded" required>
            <option value="">Select Government Hospital</option>
            <option value="hospital1">Government General Hospital</option>
            <option value="hospital2">District Government Hospital</option>
            <option value="hospital3">Primary Health Center</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Requester's Mobile Number</label>
          <input type="tel" className="w-full p-2 border rounded" required />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Relationship with Patient</label>
        <input type="text" className="w-full p-2 border rounded" required />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Reason for Requirement</label>
        <textarea className="w-full p-2 border rounded" rows={3} required></textarea>
      </div>

      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
        <h3 className="font-medium text-yellow-800 mb-2">Legal Declaration</h3>
        <p className="text-sm text-yellow-700">
          I hereby declare that all the information provided is true and accurate. I understand that providing false information
          may result in legal action. The blood units requested will be used only for the mentioned patient and purpose.
        </p>
        <div className="mt-2">
          <input type="checkbox" id="legal-agreement" className="mr-2" required />
          <label htmlFor="legal-agreement" className="text-sm">I agree to the above declaration</label>
        </div>
      </div>

      <button type="submit" className="w-full bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 transition">
        Submit Request
      </button>
    </form>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-red-700 text-white py-6">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Droplet className="h-8 w-8" />
              <h1 className="text-2xl font-bold">Blood Management System</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!formType ? (
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Welcome to Blood Management System</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <button
                onClick={() => setFormType('donor')}
                className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition flex flex-col items-center space-y-4"
              >
                <Heart className="h-12 w-12 text-red-600" />
                <h3 className="text-xl font-semibold">Donor Portal</h3>
                <p className="text-gray-600 text-center">
                  Register as a blood donor and help save lives
                </p>
              </button>

              <button
                onClick={() => setFormType('recipient')}
                className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition flex flex-col items-center space-y-4"
              >
                <Users className="h-12 w-12 text-red-600" />
                <h3 className="text-xl font-semibold">Recipient Portal</h3>
                <p className="text-gray-600 text-center">
                  Request blood for patients in need
                </p>
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setFormType(null)}
              className="mb-6 text-red-600 hover:text-red-700 flex items-center space-x-2"
            >
              ← Back to Portal Selection
            </button>
            <div className="bg-white rounded-lg shadow-md p-6">
              {formType === 'donor' ? <DonorForm /> : <RecipientForm />}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;